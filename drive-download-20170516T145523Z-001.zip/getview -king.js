var viewsData = "";
var timeData = "";


function getView() {
    var data = document.querySelectorAll('[data-store]');
    var view = data[0].getAttribute('data-store');
    var view = view.replace('{"viewerCount":', '');
    var view = view.replace('}', '');
    var d = new Date();
    var time = formatDate(d);

   	var valuetime = '"'+time+'",';
   	var valueview = view+',';

    timeData 	+=   	valuetime;
    viewsData 	+=		valueview;

}

function download(filename,stringData,random) {
  
    filename = random + filename;
	console.log(filename);
    var newStr = stringData.substring(0, stringData.length - 1);
    newStr = '[' + newStr + ']';
    var element = document.createElement('a');
    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(newStr));
    element.setAttribute('download', filename);
    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
}

function formatDate(date) {
    return date.getHours() + ':' + date.getMinutes() + ':' + date.getSeconds()
}

setInterval(getView, 1000);

setInterval(function(){
	var random = Math.random();
	download('time.txt',timeData,random);
	download('views.txt',viewsData,random);
}, 30000);



