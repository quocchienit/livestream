var stringData = "";
var firstTime = 0;

function getView() {
    var data = document.querySelectorAll('[data-store]');
    var view = data[0].getAttribute('data-store');
    var view = view.replace('{"viewerCount":', '');
    var view = view.replace('}', '');
    var d = new Date();
    var time = formatDate(d);
    var value = '{"date":"' + time + '","value":' + view + '},';
    stringData += value;
}

function download() {
    var filename = 'livestream.txt';
    var random = Math.random();
    filename = "amChart_" + random + filename;
    var newStr = stringData.substring(0, stringData.length - 1);
    newStr = '[' + newStr + ']';
    var element = document.createElement('a');
    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(newStr));
    element.setAttribute('download', filename);
    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
}

function formatDate(date) {
    if (firstTime == 0) {
        firstTime = date.getTime();
    }
    var differentTime = date.getTime() - firstTime;
    var hours = converSecondsToHours(differentTime);
    return date.getFullYear() + "-" + (parseInt(date.getMonth()) + 1) + '-' + date.getDate() + ' ' + hours;
}

function converSecondsToHours(differentTime) {
    hours = Math.floor(differentTime / 3600000), // 1 Hour = 36000 Milliseconds
        minutes = Math.floor((differentTime % 3600000) / 60000), // 1 Minutes = 60000 Milliseconds
        seconds = Math.floor(((differentTime % 360000) % 60000) / 1000) // 1 Second = 1000 Milliseconds
    return hours + ":" + minutes + ":" + seconds;
}
setInterval(getView, 1000);
setInterval(download, 30000);